    // всплывающее меню секции offers
let settingGear = document.querySelector(".settings__gear");
let settingList = document.querySelector(".settings__list");

settingGear.addEventListener("mouseover", function(event){
    if(event){
        settingList.style.display = "block";
    }  
})
settingGear.addEventListener("mouseout", function(event){
    if(event){
        settingList.style.display = "none";
    }  
})

    // всплывающее меню Гамбургер
let hamburger = document.querySelector(".hamburger");
let hideMenu = document.querySelector(".hide-menu");
let hideMenuClose = document.querySelector(".hide-menu__close");

hamburger.addEventListener("click", function(event){
    if(event){
        hideMenu.style.display = "block";
    }  
})

hideMenuClose.addEventListener("click", function(event){
    if(event){
        hideMenu.style.display = "none";
    }
})

    //Всплывающее меню Команда
$(".team__transform-element").on("click", function(event){
    event.preventDefault();
    $(this).toggleClass("view-conteiner");    
})

// let team = $(".team__list");

// team.on("click", function(e){
//     e.preventDefault();
    
//     const link = $(e.currentTarget);
    
//     if(link.classList.contains(".team__name")){

//         const activeItem = team.$(".team__transform-element.view-conteiner");
        
//         if(activeItem){
        
//             let activeText = activeItem.$(".hidden-conteiner");
//             activeText.css("height", "0px");
//             activeItem.classList.remove("view-conteiner");
//         }

//         if (!activeItem || activeItem.$(".team__name") !== link){
//             let currentElement = link.closest(".team__transform-element");
//             currentElement.classList.add("view-conteiner");
//             let currentText = currentElement.$(".hidden-conteiner");
//             currentText.style.height = currentText.scrollHeight + "px";
//         }
//     }
// })

// Отзывы
let findBlock = (block) => {
    return $(".rewiews__person").filter( (item) => {
        return $(item).attr("data-view") == block;
    })
}


$('.pagginator__element').on("click", function(e){
    e.preventDefault();

    let click = $(e.currentTarget);
    let dataOpen = click.attr("data-open");
    let currentBlock = findBlock(dataOpen);
    let currentTarget =  click.closest(".pagginator__element");
    console.log(dataOpen);
    currentBlock.addClass("isActive").siblings().removeClass("isActive");
    currentTarget.addClass("active").siblings().removeClass("active");
})